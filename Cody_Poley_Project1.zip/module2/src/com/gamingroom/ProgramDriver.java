package com.gamingroom;

/**
 * Application start-up program
 * 
 * @author coce@snhu.edu
 */
public class ProgramDriver {
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		long id = 2;
		// FIXME: obtain reference to the singleton instance
		GameService service = GameService.getInstance(); // replace null with ???
		
		System.out.println("\nAbout to test initializing game data...");
		
		// initialize with some game data
		Game game1 = service.addGame("Doom"); //add game to service
		System.out.println(game1.toString()); //prints game1 toString method
		Team teamHolder = game1.addTeam("Four Horsemen"); //adds team to game1
		game1.addTeam("Four Horsemen"); //try to add same team for a second time
		teamHolder.addPlayer("Death"); //add player
		teamHolder.addPlayer("War"); //add player
		game1.addTeam("Death"); //add second team
		System.out.println(teamHolder.toString()); //print team
		System.out.println(game1); //print game1
		System.out.println("Next Player Id: " + service.getNextPlayerId()); //get next player id
		Game game2 = service.addGame("Wolfenstein"); //add game to service
		System.out.println(game2); //print game2
		Game game3 = service.addGame("Doom"); //checking to make sure I can't add the same game
		System.out.println("Trying to enter Doom for a second time: " + game3);
		Game game4 = service.getGame(id); //checking that I can look for a id and get their instance
		System.out.println(id + ": " + game4);
		Game game5 = service.getGame("Wolfenstein"); //check to see if I can find who is play a game
		System.out.println("How is playing Wolfenstein:" + game5);
		
		// use another class to prove there is only one instance
		SingletonTester tester = new SingletonTester();
		tester.testSingleton();
		
	}
}
