package com.gamingroom;
import java.util.ArrayList;
import java.util.List;
/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity{
	//long id;
	//String name;
	private static List<Player> players = new ArrayList<Player>();
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		super(id, name);
		//this.id = id;
		//this.name = name;
	}

	public Player addPlayer(String name) {
		Player player = null;
		
		for(int i = 0; i < players.size(); i++) { //for loop that goes through the games 
			if (players.get(i).getName() == name) { //if game name is in the games returns the game instance
				return  players.get(i);
			}
		}
			// if not found, make a new game instance and add to list of games
			if (player == null) {
				player = new Player(super.getId(), name);
				players.add(player);
			}

			// return the new/existing game instance to the caller
			return player;
	}
	
	/**
	 * @return the id
	 */
	public long getId() {
		return super.getId();
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return super.getName();
	}

	@Override
	public String toString() {
		return "Team [id=" + super.getId() + ", name=" + super.getName() + "]";
	}
}
