package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

import javax.swing.Spring;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();
	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;
	private static long nextPlayerId = 3;
	private static long nextTeamId = 1;
	
	private static GameService service = new GameService(); //creating GameService object
	
	private GameService() {} //Constructor for object class GameService
	
	//public static GameService getService() { //Getting the object 
		//return service;
	//}
	
	public static GameService getInstance() { //Getting the object 
		return service;
	}
	/**
	 * The purpose of the singleton pattern is to create a simple object class that can be accessed without instantiate the object of the class. The
	 * characteristics of the singleton pattern are creating a object of the class, a constructor, a getter that gets the object, and away to show the object.  
	 */
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;
		
		for(int i = 0; i < games.size(); i++) { //for loop that goes through the games 
			if (games.get(i).getName() == name) { //if game name is in the games returns the game instance
				return  games.get(i);
			}
		}
		/**
		 * The purpose of a iterator pattern is to give access to each element of the object in this case its used to check all elements to see if the name of the 
		 * game is in any of the objects elements. The characteristics of the iterator pattern are a loop that goes through the object element to add, remove, print, or change them.
		 */
		// FIXME: Use iterator to look for existing game with same name
		// if found, simply return the existing instance

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		for (int i = 0; i < games.size(); i++) { //loops through games 
			if (games.get(i).getId() == id) { //if id is in games returns game object
				game = games.get(i);
			}
		}
		// FIXME: Use iterator to look for existing game with same id
		// if found, simply assign that instance to the local variable

		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;
		
		for (int i = 0; i < games.size(); i++) { //loops through games
			if (games.get(i).getName() == name) { //if name is in games returns game object
				game = games.get(i);
			}
		}
		// FIXME: Use iterator to look for existing game with same name
		// if found, simply assign that instance to the local variable

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size(); //returns size of games
	}
	
	public long getNextPlayerId() {
		return nextPlayerId; //returns next player id
	}
	
	public long getNextTeamId() {
		return nextTeamId; //returns next Team id
	}
}
