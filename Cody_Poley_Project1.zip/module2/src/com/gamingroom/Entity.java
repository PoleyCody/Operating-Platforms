package com.gamingroom;

public class Entity {
	private long id; 
	private String name;
	
	private Entity() {}
	/*
	 * Constructor with an identifier and name 
	 */
	public Entity(long id, String name) {
		this();
		this.id = id;
		this.name = name;
	}
	
	public long getId() {
		return id; //returns id 
	}
	
	public String getName() {
		return name; //returns name
	}
	
	public String toString() {
		return "Game [id=" + id + ", name=" + name + "]"; //returns string of id and name
	}
}
